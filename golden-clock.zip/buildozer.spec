[app]
# (str) Title of your application
title = Golden Analog Clock

# (str) Package name
package.name = goldenclock

# (str) Package domain (unique identifier, reverse DNS style)
package.domain = org.example

# (str) Source code directory (where main.py is located)
source.dir = .

# (list) Source files to include. Without this line, some buildozer versions skip files.
source.include_exts = py,png,jpg,kv,atlas

# (list) Folders to leave out of the app
source.exclude_dirs = bin,.buildozer,.github,_src,__pycache__

# (str) Application version
version = 1.0.0

# (list) Application requirements. Kivy is pinned so builds stay repeatable.
requirements = python3,kivy==2.3.0

# (bool) Fullscreen
fullscreen = 1

# (str) Supported orientations (portrait, landscape, or all)
orientation = all

# Permissions: none. A clock needs no internet, so INTERNET was removed.

# (int) Android API levels
android.api = 33
android.minapi = 21
android.ndk_api = 21

# (list) CPU architectures to build for (covers almost every phone)
android.archs = arm64-v8a, armeabi-v7a

# (bool) Automatically accept SDK licenses
android.accept_sdk_license = True

[buildozer]
# (int) Log level (0 = error only, 1 = info, 2 = debug)
log_level = 2

# (int) Display warning if buildozer is run as root (0 = off, 1 = on)
warn_on_root = 1
