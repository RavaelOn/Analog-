"""Pure-Python clock geometry (no Kivy), so it can be tested anywhere.

Angles are in degrees, measured clockwise from 12 o'clock.
y grows upward, like Kivy's coordinate system.
"""
import math


def polar(cx, cy, r, deg):
    """Point at distance r from (cx, cy) in the direction deg (clockwise from 12)."""
    a = math.radians(deg)
    return cx + r * math.sin(a), cy + r * math.cos(a)


def square_radius(half, deg, corner_limit=1.2):
    """Distance from the centre to the edge of a square of half-size `half`, along deg.

    The distance is capped so points near the corners stay inside a rounded corner.
    """
    a = math.radians(deg)
    m = max(abs(math.sin(a)), abs(math.cos(a)))  # always >= 0.707
    return min(half / m, half * corner_limit)


def hand_angles(hour, minute, second, microsecond=0, smooth=True):
    """Return (hour_deg, minute_deg, second_deg). smooth=False makes the second hand tick."""
    sec = second + (microsecond / 1_000_000.0 if smooth else 0.0)
    minute_f = minute + sec / 60.0
    hour_f = (hour % 12) + minute_f / 60.0
    return hour_f * 30.0, minute_f * 6.0, sec * 6.0


def hand_polygon(cx, cy, deg, length, half_width, tail, shoulder=0.14):
    """Flat list [x1, y1, ... x4, y4] for a tapered, kite-shaped hand.

    Thick near the centre, pointed at the tip, with a short tail behind the pivot.
    """
    a = math.radians(deg)
    dx, dy = math.sin(a), math.cos(a)      # along the hand
    px, py = math.cos(a), -math.sin(a)     # across the hand
    s = length * shoulder
    return [
        cx + dx * length, cy + dy * length,                       # tip
        cx + dx * s + px * half_width, cy + dy * s + py * half_width,  # left shoulder
        cx - dx * tail, cy - dy * tail,                           # tail
        cx + dx * s - px * half_width, cy + dy * s - py * half_width,  # right shoulder
    ]
