"""Analog wall clock for Android (Kivy).

Square clock with a brown frame, white face, black numerals, tapered black hands
and a red second hand.

Performance note: the face (frame, ticks, numerals) is drawn ONCE whenever the
window size changes. Only the three hands are updated, 30 times a second.
"""
from datetime import datetime

from kivy.app import App
from kivy.clock import Clock
from kivy.core.text import Label as CoreLabel
from kivy.core.window import Window
from kivy.graphics import Color, Ellipse, Line, Quad, Rectangle, RoundedRectangle
from kivy.uix.widget import Widget

import clockgeom as geo

# ---- Easy things to change ---------------------------------------------------
FRAME_DARK = (0.36, 0.06, 0.05)    # outer frame colour (dark brown/red)
FRAME_LIGHT = (0.52, 0.12, 0.08)   # lighter band on the frame
FACE = (1, 1, 1)                   # clock face
INK = (0.07, 0.07, 0.07)           # numerals, ticks and hour/minute hands
SECOND_HAND = (0.86, 0.10, 0.14)   # red second hand
BRASS = (0.78, 0.62, 0.22)         # centre pin
SMOOTH_SECONDS = True              # False = the second hand ticks once per second
LABEL = "QUARTZ"                   # small text under the centre ("" to hide)
# ------------------------------------------------------------------------------


class AnalogClock(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._ready = False
        self.bind(pos=self.rebuild, size=self.rebuild)
        Clock.schedule_interval(self.tick, 1.0 / 30.0)

    # ---- helpers ----------------------------------------------------------
    @staticmethod
    def _text(text, x, y, font_size, bold=True):
        label = CoreLabel(text=str(text), font_size=int(font_size), bold=bold)
        label.refresh()
        tex = label.texture
        tw, th = tex.size
        Rectangle(texture=tex, pos=(x - tw / 2.0, y - th / 2.0), size=(tw, th))

    # ---- static face (drawn once per size change) ------------------------------
    def rebuild(self, *args):
        self.canvas.clear()
        w, h = self.size
        s = min(w, h)
        if s <= 0:
            self._ready = False
            return

        cx, cy = self.x + w / 2.0, self.y + h / 2.0
        half = s * 0.47                 # half of the frame's outer side
        frame = half * 0.12             # frame thickness
        fh = half - frame               # half of the face's side
        corner = half * 0.18            # outer corner radius
        self._cx, self._cy, self._fh = cx, cy, fh

        with self.canvas:
            # Frame
            Color(*FRAME_DARK)
            RoundedRectangle(pos=(cx - half, cy - half), size=(2 * half, 2 * half),
                             radius=[corner])
            band = frame * 0.18
            Color(*FRAME_LIGHT)
            RoundedRectangle(pos=(cx - half + band, cy - half + band),
                             size=(2 * (half - band), 2 * (half - band)),
                             radius=[corner - band])
            # Thin grey lip, then the white face
            lip = frame * 0.12
            Color(0.80, 0.80, 0.80)
            RoundedRectangle(pos=(cx - fh - lip, cy - fh - lip),
                             size=(2 * (fh + lip), 2 * (fh + lip)),
                             radius=[corner - frame * 0.6])
            Color(*FACE)
            RoundedRectangle(pos=(cx - fh, cy - fh), size=(2 * fh, 2 * fh),
                             radius=[corner - frame * 0.7])

            # Minute and hour ticks around the edge of the square face
            Color(*INK)
            for m in range(60):
                deg = m * 6
                outer = geo.square_radius(fh * 0.93, deg, 1.12)
                length = fh * (0.085 if m % 5 == 0 else 0.045)
                x1, y1 = geo.polar(cx, cy, outer - length, deg)
                x2, y2 = geo.polar(cx, cy, outer, deg)
                Line(points=[x1, y1, x2, y2],
                     width=max(1.0, fh * (0.018 if m % 5 == 0 else 0.008)))

            # Numerals on a rounded-square path (11-12-1 share the top row, like the photo)
            for hour in range(1, 13):
                deg = hour * 30
                r = geo.square_radius(fh * 0.69, deg, 1.15)
                nx, ny = geo.polar(cx, cy, r, deg)
                self._text(hour, nx, ny, fh * 0.26)

            if LABEL:
                Color(0.35, 0.35, 0.35)
                self._text(LABEL, cx, cy - fh * 0.40, fh * 0.085, bold=False)

            # ---- hands: created once, updated by tick() ----
            Color(*INK)
            self._hour = Quad(points=[0] * 8)
            self._minute = Quad(points=[0] * 8)

            Color(*SECOND_HAND)
            self._second = Line(points=[cx, cy, cx, cy], width=max(1.0, fh * 0.012),
                                cap='round')
            self._dot_size = fh * 0.075
            self._dot = Ellipse(pos=(cx, cy), size=(self._dot_size, self._dot_size))

            Color(*BRASS)
            pin = fh * 0.05
            Ellipse(pos=(cx - pin, cy - pin), size=(2 * pin, 2 * pin))

        self._ready = True
        self.tick(0)

    # ---- moving parts (30 times a second) ----------------------------------------
    def tick(self, dt):
        if not self._ready:
            return
        cx, cy, fh = self._cx, self._cy, self._fh
        now = datetime.now()
        hour_deg, min_deg, sec_deg = geo.hand_angles(
            now.hour, now.minute, now.second, now.microsecond, SMOOTH_SECONDS)

        self._hour.points = geo.hand_polygon(
            cx, cy, hour_deg, fh * 0.50, fh * 0.055, fh * 0.10)
        self._minute.points = geo.hand_polygon(
            cx, cy, min_deg, fh * 0.78, fh * 0.042, fh * 0.10)

        tip = geo.polar(cx, cy, fh * 0.88, sec_deg)
        tail = geo.polar(cx, cy, -fh * 0.22, sec_deg)
        self._second.points = [tail[0], tail[1], tip[0], tip[1]]
        dx, dy = geo.polar(cx, cy, -fh * 0.24, sec_deg)
        self._dot.pos = (dx - self._dot_size / 2.0, dy - self._dot_size / 2.0)


class ClockApp(App):
    title = "Golden Analog Clock"

    def build(self):
        Window.clearcolor = (0.97, 0.97, 0.97, 1)
        try:
            Window.allow_screensaver = False   # best effort: keep the screen awake
        except Exception:
            pass
        return AnalogClock()   # fills the window; the clock stays square inside it


if __name__ == "__main__":
    ClockApp().run()
